== PLEASE NOTE THAT THE ACCOMPANYING SPREADSHEET CONTAINS MACROS AND THAT IT IS PROVIDED AS IS.  IT IS YOUR RESPONSIBILITY TO BE CERTAIN WHAT YOU HAVE DOWNLOADED IS SAFE.  ALL I CAN GUARANTEE IS THAT IT WAS SAFE WHEN I PUBLISHED IT; I CANNOT VERIFY FOR YOU WHETHER THE CODE IT CONTAINS NOW IS THE SAME AS WHAT I RELEASED ==



This Excel spreadsheet is designed to simulate Legend of Mana's Tempering subroutines, enabling the user to test recipes outside the game much more quickly and with more customization.  As such, it has a number of features to increase ease of use.

Macros are required for the spreadsheet to run.  However, if you just want the data lists, feel free to keep them disabled.

The LoMForge97.xls file is specifically for Excel 97.  It is functionally the same as the other version, but had to have a small hack placed into it to get around an annoying bug in this version of Excel.  The difference is minimal and barely noticable, but both versions are included just in case.

 ---

The last four sheets (Type, Materials, Secondary and Cards) are all data tables and should not be edited.  They contain the raw data that the tempering program will use.  The true meat of the program rests in the first sheet.  Note however that the Class IDs and the extra information in the Secondary sheet (with the light gray/dark gray background) are for your own reference only and are not used by the macros.

The first sheet - Forge - displays the item being worked on.  To create a new item, use the Material and Type ID numbers to change the weapons properties.  Once you have selected the correct IDs, hit 'Reset Item' to generate the base stats.  This will change all the derived values to their default values for that item, as well as generate the default name.  

Much of this can be freely changed after this.  Element, Markers, Stat and Immunity levels can be modified if you so wish, but for the most part, you will want to leave them alone and let the Temper code do the work.

The 'Update Item' button generates new stats for the item based on new materials or equipment types, but does not change the tempered stats.  It does not run Mystic Card code, however, so Offensive and Defensive values may be lower than they should be with regards to varnishing.

The 'Temper Item' button does the real work.  The item being tempered must be entered into the Next Temper box.  If you use the wrong case and capitalization, the program will correct it for you when you hit the 'Temper Item' button.  Additionally, as a shortcut, you may instead input the numerical ID for the item which can be found in the Secondary sheet.  For example, a shortcut for Glow Crystals would be 86.

The 'Next Recipe Step' button will be covered when we touch on the Recipe worksheet.

 ---

The Temper List sheet records every item you temper into your equipment.  It is cleared if you hit the 'Reset Item', but you can clear it manually without affecting the item by hitting the 'Clear Temper List' button on the Temper List sheet.

Also in the Temper List is the "Recipe Code".  A letter-based code representing everything entered into the Temper List is generated whenever you click the 'Save State' button on the Forge sheet.  'Save State' will also create a code for the item you're working on, storing it in the Save Code box in the Forge sheet.  Both can be used to save items in a text file for later use, or to try out possible temper options without having to redo everything.  The 'Load State' button the Forge sheet resets both the Forge and Temper List sheets and replaces them with the information from the Save Code and Recipe Code.

 ---

Finally, the Recipe sheet allows you to enter complete recipes for the code to follow.  The Start value for a recipe dictates which ID in the list the recipe starts at.  If the "Stop at End Value" box is checked, an End value must also be selected.  When the 'Start Recipe' button is pressed, all the items from Start ID to the end (or End ID if given) will be tempered into the item.  Again, 'Save Recipe' and 'Load Recipe' buttons exist to help in storing recipes in an easily copy-and-pastable form.  The codes generated are fully compatible with the codes in the Temper List sheet.

The program will warn you if you have made a mistake in typing in an item's ID or name.  The numerical ID shortcuts also work here: you can type in 241 for Needle as an example.  The _Recipe_ code will automatically expand and correct any shortcuts you make when you run it.  In addition, you may indicate the number of a certain item to temper at once.  If no number is specified, the recipe assumes it must only be run once.  You cannot specify 0 however; each item *will* be run at least once.

You can also check the "Switch to Forge Screen after Recipe End" box to move you to the Forge Worksheet once the recipe has finished.

Finally, back on the Forge sheet, the 'Next Recipe Step' button will run the *immediate* next step in the current recipe.  The default start is 'Step 1, Repeat 1', which means the first item of the first step.  If there are multiple items in a single step, then 'Next Recipe Step' will only do one of them and increment the Repeat count.  Only when the Repeat count indicates that all the items in a single step have been tempered will it move on to the next step.  In this way, it is possible to watch a Recipe's effects from beginning to end, keeping an eye out for any anomalies or mistakes that may have been made.  It is also possible to learn more about how a recipe works using this feature.

Also, if you have the "Show Temper Item for Next Recipe Step" box ticked, then the Temper Item that will be used next will be placed in the Next Temper cell.  Otherwise, the item in the box will be the *last* item tempered.



A Brief Tutorial
================

Let's make a quick starting weapon to practice some basic tempering, shall we?  A LorantSilver Sword should do the trick.

First, look up the IDs for LorantSilver in the Materials list, and Sword in the Type list.  LorantSilver is ID 3, while a Sword is ID 1.  So, we enter 3 and 1 into the ID boxes for Material and Type in the Forge List.  Now hit the 'Reset Item' button.

The Name box will change to reflect the fact that you're now working on a LoraSword.  The stats will have reset to defaults, and now we can start work.

For this tutorial, we'll try tempering in a bit of Sala Essense.

Go to the Next Temper box, and in the empty space provided, type "Sala Silver" without the quotes, and hit Enter.  Once you've done this, you can click the 'Temper Item' button to temper it in.

Immediately, a Salamander card will appear in the Hidden slot, and Sala Essense will jump up to L1.  We also earned a Sala Marker and a couple extra points of Offense from this!

Hold the mouse over the Sala Lv box, just below and to the left of the red triangle.  A comment will appear shortly saying "_14_ /6/2/2 Energy Required".  The energy we need to get to the next level of Sala has increased from 7 to 14!  The other numbers - 6, 2 and 2 - refer to the energy required if we had the relevant number of Wizard cards active on the item.  (NB: This energy indicator will never take into account the presence of a Tower card, since the only time a Tower is more useful than an extra Wizard card is when working with MaiaLead)

Note the Wasted Energy box underneath the Sala Silver.  We had 41 Wasted Energy.  We could've used a Firestone instead to get the same effect with less energy.  So let's try that and see what happens.

Click the 'Reset Item' button.  This time, we will temper in a Firestone.  But instead of typing in Firestone, we will look up its ID first.

Go to the Secondary sheet and look for Firestone in the Name column.  Its ID is 80, and it has 24 Energy.  That would be plenty just to get to L1.

Now that we know its ID, type "80" without the quotes into the Next Temper box and hit Enter.  Then click 'Temper Item'.

Note that the program has immediately detected what item we were referring to and replaced our 80 with Firestone.  In addition, we have gained all the bonuses before, but this time with less energy wasted: 17 instead of 41!  Firestones can also be bought, unlike the Silver coins, so it's a good deal all-round.

Now, let's try some things from here.  First, let's save our current status.  Hit the 'Save State' button.

Note that the Save Code has changed, and now contains an encoded version of our item as it is now.  Look at the Temper List sheet as well.  The code 'FAB' should be in the Recipe Code box, which is a coded representation of the single Firestone we've put in.

Now, back to the Forge sheet.  Hit Temper Item again to put in a second Firestone.

Note that we went up to Sala L2 now.  However, the Salamander card on the item was pushed down to Slot 1, and could've added a *second* level if we had enough energy.  We had 10 Wasted Energy left, and we needed 28 to get to L3 by looking at the comment.  So we need to find 18 more Energy.

Sala Silvers, if you recall, have 48 Energy, which is 24 more Energy than a Firestone.  Let's try that!

Hit the 'Load State' button.  Note that we have reverted back to when the item only had one Firestone in it.  You can check the Temper List to confirm this; only one item is in there.

Now enter "Sala Silver" into the Next Temper box and temper it in.  This time, we jump immediately up to L3 Sala!

Now that we've covered the basics, let's look at Recipes.  First, save the item using 'Save State'.  Then go to the Recipe box.

We're going to go up to L9 Sala by entering the following recipe.  Starting from ID 1 in the Recipe, enter the following in the Item Tempered column:
   Glow Crystal
   Sala Silver
   Sulpher
   Glow Crystal
   Sulpher
   Sala Silver
   Glow Crystal
   Sulpher
   Sala Gold

In the box to the right of each Glow Crystal, put the number 4.  In the box to the right of each Sulpher, put the number 3.  This means we want to temper *4* Glow Crystals in a row, and *3* Sulphers in a row when we get to these parts of the recipe.

Once we've done all this, check the number to the right of "Start" and make sure it says 1.  Also, make sure that the 'Stop at End Value' box does not have a tick in it.  If it does, click it once to remove the tick.  There should also be a tick in the 'Switch to Forge Screen after Recipe End' box, to save us from doing it manually once we're done.

Now hit the 'Start Recipe' button.

If all went well, we should be back in the Forge Screen.  Our Sala Essense Lv should now be 9 if the Recipe went correctly.  If it isn't, check that you put the correct numbers for the ingredients: we want to temper in 4 Glow Crystals at a time and 3 Sulphers at a time.  Also, if you got any errors, check that you haven't made any typos or put information in the wrong boxes.

You can also check the Temper List sheet, and see the complete list of items that got you to this state.

Go back to 'Forge' and click the 'Save State' button.  Then hit the 'Reset Item' button.  We're going to try one last thing.

Move to the Temper List sheet and look at the Recipe Code.  It should be a lot longer now, because it has more items to store.

Select the cell and choose to copy the contents to the Clipboard (you can do this by hitting Ctrl and C at the same time, or do it via the Edit menu).  Now go to the Recipe sheet and *PASTE* the code into the box next to Recipe Code there.  The code should be:
   FABEMBFGEEMBOADFGEOADEMBFGEOADEEB

Now hit the 'Load Recipe' button.  The recipe already there should vanish and be replaced with the list of items we generated making the old item.  Now that we've imported the recipe, we can use it to regenerate the item again.  Hit the 'Start Recipe' button.

And as you can see, we have our L9 Weapon back!

It is, though, important to remember that recipes don't care what material or item they're working on.  If we had tried this on a SwifteRock item, we certainly wouldn't have gotten up to L9 in Salamander.

This ends the basic tutorial.  By now, you should see how things in Legend of Mana relate to the spreadsheet, and thus be able to use it to make your own recipes.  Have fun!



